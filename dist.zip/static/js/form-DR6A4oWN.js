import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-DreFWz0_.js";import"./index-CsrB2J66.js";import"./index-D3FY82Rz.js";export{o as default};
