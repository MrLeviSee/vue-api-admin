import{_ as o}from"./role.vue_vue_type_script_setup_true_lang-C8TsdP1P.js";import"./index-CsrB2J66.js";import"./index-D3FY82Rz.js";export{o as default};
