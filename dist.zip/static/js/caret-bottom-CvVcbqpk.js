const t={width:1024,height:1024,body:'<path fill="currentColor" d="m192 384l320 384l320-384z"/>'};export{t as d};
