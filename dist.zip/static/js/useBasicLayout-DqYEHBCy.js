import{b0 as s,b1 as i}from"./index-mYLF6Mpb.js";function t(){return{isMobile:s(i).smaller("sm")}}export{t as u};
