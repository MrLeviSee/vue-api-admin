import{_ as m}from"./description.vue_vue_type_style_index_0_lang-DZHckEZL.js";import"./index-D3FY82Rz.js";export{m as default};
