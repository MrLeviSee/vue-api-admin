import{_ as m}from"./ChartRound.vue_vue_type_script_setup_true_lang-B4RiIs35.js";import"./index-D3FY82Rz.js";export{m as default};
