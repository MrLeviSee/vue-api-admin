import{_ as m}from"./description.vue_vue_type_style_index_0_lang-BC0sNtEO.js";import"./index-mYLF6Mpb.js";export{m as default};
