import{_ as o}from"./role.vue_vue_type_script_setup_true_lang-CIVmiyZx.js";import"./index-BlhlkIPw.js";import"./index-mYLF6Mpb.js";export{o as default};
