import{b3 as s,b4 as i}from"./index-D3FY82Rz.js";function t(){return{isMobile:s(i).smaller("sm")}}export{t as u};
